print("Hello world!")
print("Name: Princess Dianne Principe")
print("Course: Information Technology")
print("Interests in programming: AI and Web Development")
